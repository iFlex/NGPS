//
//  main.m
//  WoL
//
//  Created by MLF on 12/05/2014.
//  Copyright (c) 2014 MLF. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "wolAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([wolAppDelegate class]));
    }
}

//
//  wolViewController.m
//  WoL
//
//  Created by MLF on 12/05/2014.
//  Copyright (c) 2014 MLF. All rights reserved.
//

#import "wolViewController.h"

@interface wolViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *browser;

@end

@implementation wolViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    NSURL *htmlFile = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"core/index" ofType:@"html"]];
    [_browser loadRequest:[NSURLRequest requestWithURL:htmlFile]];
    /*
    [super viewDidLoad];
	NSString *htmlFile = [[NSBundle mainBundle] pathForResource:@"core/index" ofType:@"html"];
    NSString* htmlString = [NSString stringWithContentsOfFile:htmlFile encoding:NSUTF8StringEncoding error:nil];
    [_browser loadHTMLString:htmlString baseURL:nil];*/
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

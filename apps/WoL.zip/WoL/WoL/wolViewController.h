//
//  wolViewController.h
//  WoL
//
//  Created by MLF on 12/05/2014.
//  Copyright (c) 2014 MLF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface wolViewController : UIViewController

@end

Regional.extend("en", {
	"EDIT_browse":"browse",
	"EDIT_Add_Picture":"Add Picture",
	"EDIT_Add_Video":"Add Video",
	"EDIT_IMAGE_LINK":"Paste image link here",
	"EDIT_VIDEO_LINK":"Paste video link here",
});

Regional.extend("ro",{
	"EDIT_browse":"alege",
	"EDIT_Add_Picture":"Adauga Poza",
	"EDIT_Add_Video":"Adauga Video",
	"EDIT_IMAGE_LINK":"linkul imaginii aici",
	"EDIT_VIDEO_LINK":"linkul videoului aici",
});
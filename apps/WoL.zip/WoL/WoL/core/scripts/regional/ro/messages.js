Regional.extend("ro",{
	"I<3U":"Te iubesc NGPS",
});
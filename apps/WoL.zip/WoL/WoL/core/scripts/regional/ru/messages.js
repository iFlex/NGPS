Regional.extend("ru",{
	"I<3U":"я тебя люблю NGPS!",
});
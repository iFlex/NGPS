Regional.extend("bg",{
	"I<3U":"Обичам те NGPS!",
});
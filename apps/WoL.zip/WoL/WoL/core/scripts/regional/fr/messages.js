Regional.extend("fr",{
	"I<3U":"Je t'aime NGPS!",
});
Regional.extend("sr",{
	"I<3U":"волим те NGPS!",
});
Regional.extend("en",{
	"I<3U":"I love you NGPS!",
});
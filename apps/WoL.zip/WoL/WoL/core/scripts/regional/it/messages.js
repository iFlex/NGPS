Regional.extend("it",{
	"I<3U":"Ti amo NGPS!",
});
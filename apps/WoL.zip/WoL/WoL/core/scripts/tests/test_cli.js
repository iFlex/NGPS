/**
*	NGPS CLI test module
*	Author: Milorad Liviu Felix
*	12 Jun 2014 00:21 GMT
*/
 function init()
 {
 	cli.show();
 }

 
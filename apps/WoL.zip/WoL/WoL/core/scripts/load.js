/**
*	NGPS load module
*	Author: Milorad Liviu Felix
*	13 Jun 2014  00:33 GMT
* 	This module reads the index.html, builds the object tree and renders the presentation
*/

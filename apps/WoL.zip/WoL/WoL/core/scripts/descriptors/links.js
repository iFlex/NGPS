/** 
*	Container Models File
*	States container descriptor & resources needed
*	Mod de operare: descrie direct proprietatile sau indica fisierul CSS necesar + clasa necesara
*	Author:
* 	31 May 2014 14:20
*/
//initialise
this.Descriptors = this.Descriptors || {}
Descriptors.links = Descriptors.links || {};
Descriptors.links['l000000'] = { name:"Simple" , x:0 , y:0 , width:100 , height:5 , cssText : "background: black;" };
Descriptors.links['l000001'] = { name:"Dashed" , x:0 , y:0 , width:100 , height:5 , cssText : "border-width:5px;border-style:dashed;background: red;" };
